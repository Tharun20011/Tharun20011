package step_definition;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import junit.framework.Assert;

public class Login_steps {
	
	WebDriver driver = null;
	static String url;
	@Given("open the spicejet protel")
	public void open_the_spicejet_protel() {
		System.out.println("open the spicejet protel");
		System.setProperty("webdriver.edge.driver","C:\\Users\\tharunbalaji.sk\\eclipse-workspace\\Assigment1\\src\\test\\resources\\drivers\\msedgedriver.exe");
		
		driver = new EdgeDriver();
		driver.get("https://www.spicejet.com/");
		
		String url = driver.getCurrentUrl();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		
	   
	}
	@Given("login to the webpage")
	public void login_to_the_webpage() {
		System.out.println("user gives the login username and password");
		driver.findElement(By.xpath("//*[@id=\"main-container\"]/div/div[1]/div[2]/div[1]/div/div[3]/div[1]")).click();
		driver.findElement(By.xpath("//*[@id=\"main-container\"]/div/div[3]/div[2]/div[2]/div[2]/div/div[4]/div[2]/input")).sendKeys("7397361525");
		driver.findElement(By.xpath("//*[@id=\"main-container\"]/div/div[3]/div[2]/div[2]/div[2]/div/div[5]/div[1]/div[2]/input")).sendKeys("Tharun@2001");
		driver.findElement(By.xpath("//*[@id=\"main-container\"]/div/div[3]/div[2]/div[2]/div[2]/div/div[5]/div[3]")).click();
		System.out.println("sucessfully loggedin	");
	    
	}
	
	

	@When("navigate to addon links and verify the title")
	public void navigate_to_addon_links_and_verify_the_title() {
		
		WebElement ele = driver.findElement(By.xpath("//*[@id=\"main-container\"]/div/div[1]/div[2]/div[1]/div/div[2]/div[1]/div/div[1]"));

		
		Actions action = new Actions(driver);

	
		action.moveToElement(ele).perform();
		
		driver.navigate().to("https://book.spicejet.com/SpiceMax.aspx?AddSeat=true");
		String spicemaxtitle1 = driver.getTitle();
		String spicemaxtitle = "Cheap Air Tickets Online, International Flights to India, Cheap International Flight Deals | SpiceJet Airlines";
		
		if(spicemaxtitle.equals(spicemaxtitle1))	{
			System.out.println(spicemaxtitle1);
		}
		else {
			System.out.println("Title1 is incorrect");
		}
		driver.navigate().to("https://book.spicejet.com/RetrieveBooking.aspx?AddMeal=true");
		String hotmealstitle1 = driver.getTitle();
		String hotmealstitle = "Cheap Air Tickets Online, International Flights to India, Cheap International Flight Deals | SpiceJet Airlines";
		
		if(hotmealstitle.equals(hotmealstitle1))	{
			System.out.println(hotmealstitle1);
		}
		else {
			System.out.println("Title2 is incorrect");
		}
		driver.navigate().to("https://corporate.spicejet.com/thrillophilia.aspx");
		String activitiestitle1 = driver.getTitle();
		String activitiestitle = "SpiceJet";
		
		if(activitiestitle.equals(activitiestitle1))	{
			System.out.println(activitiestitle1);
		}
		else {
			System.out.println("Title3 is incorrect");
		}
		driver.navigate().to("https://www.spicejet.com/");
		
		String flighttext = driver.findElement(By.xpath("//*[@id=\"main-container\"]/div/div[1]/div[3]/div[2]/div[1]/div[1]/div[1]")).getText();
		System.out.println(flighttext);
		
		driver.findElement(By.cssSelector("div.css-76zvg2.r-cqee49.r-ubezar.r-1ozqkpa")).click();
		driver.findElement(By.cssSelector("input.css-1cwyjr8.r-homxoj.r-ubezar.r-1eimq0t.r-1e081e0.r-xfkzu9.r-lnhwgy")).sendKeys("123456");
		driver.findElement(By.xpath("//*[@id=\"main-container\"]/div/div[1]/div[3]/div[2]/div[3]/div[2]/div[2]/input")).sendKeys("thaha@gmail.com");
		driver.findElement(By.xpath("//*[@id=\"main-container\"]/div/div[1]/div[3]/div[2]/div[4]")).click();
	
		
		driver.findElement(By.cssSelector("div.css-76zvg2.r-jwli3a.r-ubezar.r-1ozqkpa")).click();
		
		String element = driver.findElement(By.cssSelector("div.css-1dbjc4n.r-1awozwy.r-19m6qjp.r-z2wwpe.r-1loqt21.r-18u37iz.r-1777fci.r-1w50u8q.r-ah5dr5.r-1otgn73.r-13qz1uu")).getAttribute("background-color");
	System.out.println(element );
	
	}

	@When("select flight tab and search a flight ticket for student")
	public void select_flight_tab_and_search_a_flight_ticket_for_student() {
	    
	}

	@Then("validate and print high value ticket and come out of the protel")
	public void validate_and_print_high_value_ticket_and_come_out_of_the_protel() {
	    
	}

}





